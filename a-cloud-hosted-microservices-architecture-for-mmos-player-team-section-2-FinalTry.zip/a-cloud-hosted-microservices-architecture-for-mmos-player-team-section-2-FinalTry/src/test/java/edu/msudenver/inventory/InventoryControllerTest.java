package edu.msudenver.inventory;

public class InventoryControllerTest {
}
